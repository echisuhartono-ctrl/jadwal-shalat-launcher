# Jadwal Shalat Launcher v0.1

Basis web: v0.4.61 per-image-delete-from-v48.

## Fitur wrapper Android
- Mendeklarasikan aplikasi sebagai Home/Launcher Android.
- Mendukung kategori Leanback untuk Android TV.
- Landscape dan fullscreen immersive.
- Web app dimuat secara lokal dari `assets`.
- Keluar launcher dengan menekan dan menahan tombol BACK selama 5 detik.
- Dialog konfirmasi sebelum keluar.

## Catatan
- Default Home perlu dipilih pada perangkat Android TV.
- Auto power-on setelah listrik kembali tetap bergantung pada pengaturan perangkat TV/box.
- Proyek memakai Android Gradle Plugin 3.5.4, compileSdk 28, minSdk 19.

## Build melalui GitHub Actions

Lihat `README-GITHUB-ACTIONS.md`. Workflow otomatis tersedia di `.github/workflows/build-apk.yml`.
