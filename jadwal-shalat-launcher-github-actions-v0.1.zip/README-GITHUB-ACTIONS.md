# Build APK melalui GitHub Actions

1. Buat repository GitHub baru, misalnya `jadwal-shalat-launcher`.
2. Upload seluruh isi folder proyek ini ke repository (bukan file ZIP di dalam repository).
3. Buka tab **Actions**.
4. Pilih workflow **Build Jadwal Shalat APK**.
5. Tekan **Run workflow** jika ingin menjalankan manual.
6. Tunggu sampai status hijau (Success).
7. Buka hasil workflow, lalu bagian **Artifacts**.
8. Unduh `jadwal-shalat-launcher-debug` dan ekstrak untuk memperoleh `app-debug.apk`.

Catatan:
- Build menggunakan Java 8, Gradle 5.6.4, dan Android Gradle Plugin 3.5.4.
- APK debug belum ditandatangani untuk publikasi Play Store, tetapi dapat digunakan untuk instalasi/pengujian.
- Jika build gagal, buka workflow yang gagal lalu salin bagian error merah untuk diperiksa.
