package id.jadwalshalat.launcher;

import android.app.AlertDialog;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.DialogInterface;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final long EXIT_HOLD_MS = 5000L;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean backHeld = false;
    private Runnable exitRunnable;
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        enableImmersiveMode();

        webView = new WebView(this);
        configureWebView(webView);
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");

        exitRunnable = new Runnable() {
            @Override
            public void run() {
                if (backHeld) {
                    backHeld = false;
                    showExitConfirmation();
                }
            }
        };
    }

    private void configureWebView(WebView view) {
        WebSettings settings = view.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setSupportZoom(false);
        view.setWebViewClient(new WebViewClient());
        view.setWebChromeClient(new WebChromeClient());
        view.setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );
    }

    private void enableImmersiveMode() {
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );
    }

    private void showExitConfirmation() {
        new AlertDialog.Builder(this)
            .setTitle("Keluar dari Launcher?")
            .setMessage("Aplikasi Jadwal Shalat akan ditutup. Anda dapat memilih launcher Android lainnya.")
            .setNegativeButton("Batal", new DialogInterface.OnClickListener() {
                @Override public void onClick(DialogInterface dialog, int which) {
                    enableImmersiveMode();
                }
            })
            .setPositiveButton("Keluar", new DialogInterface.OnClickListener() {
                @Override public void onClick(DialogInterface dialog, int which) {
                    finishAndRemoveTask();
                }
            })
            .setOnDismissListener(new DialogInterface.OnDismissListener() {
                @Override public void onDismiss(DialogInterface dialog) {
                    enableImmersiveMode();
                }
            })
            .show();
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
            if (event.getAction() == KeyEvent.ACTION_DOWN) {
                if (event.getRepeatCount() == 0) {
                    backHeld = true;
                    handler.postDelayed(exitRunnable, EXIT_HOLD_MS);
                }
                return true;
            } else if (event.getAction() == KeyEvent.ACTION_UP) {
                backHeld = false;
                handler.removeCallbacks(exitRunnable);
                return true;
            }
        }
        return super.dispatchKeyEvent(event);
    }

    @Override
    public void onBackPressed() {
        // Disabled intentionally. Exit requires holding BACK for 5 seconds.
        Toast.makeText(this, "Tahan tombol BACK selama 5 detik untuk keluar", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        enableImmersiveMode();
    }
}
