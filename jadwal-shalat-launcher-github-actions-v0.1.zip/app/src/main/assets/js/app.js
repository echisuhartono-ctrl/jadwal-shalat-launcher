(function(){
"use strict";
var KEY="jadwalShalatConfig";
var LOC={
DIY:{name:"DI Yogyakarta",regencies:{Gunungkidul:{districts:{Panggang:{villages:{Girisuko:{lat:-8.033,lng:110.434}}}}},Bantul:{districts:{Bantul:{villages:{"Bantul":{lat:-7.888,lng:110.328}}}}},Sleman:{districts:{Sleman:{villages:{Sleman:{lat:-7.715,lng:110.355}}}}},Yogyakarta:{districts:{Danurejan:{villages:{Yogyakarta:{lat:-7.797,lng:110.369}}}}}}},
JATENG:{name:"Jawa Tengah",regencies:{Klaten:{districts:{Klaten:{villages:{Klaten:{lat:-7.705,lng:110.606}}}}}}},
JATIM:{name:"Jawa Timur",regencies:{Surabaya:{districts:{Genteng:{villages:{Surabaya:{lat:-7.257,lng:112.752}}}}}}},
JABAR:{name:"Jawa Barat",regencies:{Bandung:{districts:{Bandung:{villages:{Bandung:{lat:-6.917,lng:107.619}}}}}}},
DKI:{name:"DKI Jakarta",regencies:{JakartaPusat:{districts:{Gambir:{villages:{Jakarta:{lat:-6.175,lng:106.827}}}}}}}
};
var defaults={name:"JADWAL SHALAT MASJID",location:"Silakan atur identitas masjid",province:"DIY",regency:"Gunungkidul",district:"Panggang",village:"Girisuko",lat:-8.033,lng:110.434,asr:"Standard",dhuha:15,running:"Jadwal shalat harian • Luruskan dan rapatkan shaf • Pastikan jam perangkat akurat.",runningSpeed:28,info:"Selamat datang di masjid. Semoga Allah memberkahi jamaah dan seluruh kegiatan masjid.",cash:0,note:"Semoga Allah memberkahi masjid ini.",slideEnabled:false,slideAfter:15,slideBefore:15,slideDuration:15,slideScheduleEnabled:true,slideScheduleDays:[0,1,2,3,4,5,6],slideScheduleStart:'00:00',slideScheduleEnd:'23:59',adjust:{Subuh:0,Syuruq:0,Dzuhur:0,Ashar:0,Maghrib:0,Isya:0},iqamah:{Subuh:20,Dzuhur:10,Ashar:10,Maghrib:5,Isya:10}};
var cfg=load(),times={},lastDate="",lastBeepKey="",audioCtx=null,appReady=false;
var slides=[],localSlides=[],slideIndex=0,slideTimer=null,localSlideMode=false;
var brandingDb=null,brandingImage="";
var DEFAULT_LOGO="data:image/svg+xml;charset=UTF-8,"+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 256"><rect width="256" height="256" rx="42" fill="#f4f1e8"/><path d="M28 166h200v18H28zM42 150h172v12H42zM58 145V94l70-48 70 48v51h-24v-43h-28v43h-36v-43H82v43z" fill="#b18a25"/><path d="M113 145v-38h30v38z" fill="#8a8a8a"/><path d="M128 28l12 18h-24zM122 22h12v18h-12z" fill="#b18a25"/><circle cx="128" cy="78" r="10" fill="#8a8a8a"/></svg>');

var onlineState="Menghubungkan ke server jadwal...", onlineLastSync="", onlineBusy=false;
var API_BASE="https://api.myquran.com/v3/sholat";
var CACHE_KEY="jadwalShalatOnlineCache_v3";
function normalizeIqamahConfig(){
 var def={Subuh:20,Dzuhur:10,Ashar:10,Maghrib:5,Isya:10},n,v;
 cfg.iqamah=cfg.iqamah&&typeof cfg.iqamah==='object'?cfg.iqamah:{};
 for(n in def){v=parseInt(cfg.iqamah[n],10);if(!isFinite(v)||v<0)cfg.iqamah[n]=def[n];else cfg.iqamah[n]=Math.min(120,v)}
}
normalizeIqamahConfig();
function getAudioContext(){try{if(!audioCtx){var AC=window.AudioContext||window.webkitAudioContext;if(!AC)return null;audioCtx=new AC()}return audioCtx}catch(e){return null}}
function unlockAudio(done){var ctx=getAudioContext();if(!ctx){if(done)done(false);return false}try{if(ctx.state==="suspended"&&ctx.resume){var r=ctx.resume();if(r&&r.then){r.then(function(){if(done)done(true)}).catch(function(){if(done)done(false)});return true}}if(done)done(true);return true}catch(e){if(done)done(false);return false}}
function playBeepNow(freq,dur){try{var ctx=getAudioContext();if(!ctx)return false;var o=ctx.createOscillator(),g=ctx.createGain(),now=ctx.currentTime,d=Math.max(.55,Number(dur)||.80);o.type="sine";o.frequency.value=freq||880;g.gain.setValueAtTime(.0001,now);g.gain.exponentialRampToValueAtTime(.52,now+.035);g.gain.exponentialRampToValueAtTime(.0001,now+d);o.connect(g);g.connect(ctx.destination);o.start(now);o.stop(now+d+.08);return true}catch(e){return false}}
function playNotificationTone(kind){try{var ctx=getAudioContext();if(!ctx)return false;var now=ctx.currentTime;var notes=kind==="iqamah"?[950,1180,950]:[700,900,1100];var offsets=[0,.24,.48],master=ctx.createGain();master.gain.setValueAtTime(.0001,now);master.gain.exponentialRampToValueAtTime(.78,now+.035);master.gain.setValueAtTime(.78,now+.50);master.gain.exponentialRampToValueAtTime(.0001,now+.82);master.connect(ctx.destination);for(var i=0;i<notes.length;i++){var o=ctx.createOscillator(),g=ctx.createGain(),t=now+offsets[i];o.type="sine";o.frequency.value=notes[i];g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(.70,t+.025);g.gain.exponentialRampToValueAtTime(.0001,t+.20);o.connect(g);g.connect(master);o.start(t);o.stop(t+.24)}return true}catch(e){return false}}
function playNotificationNow(kind){var ok=playNotificationTone(kind);if(ok){setTimeout(function(){try{playNotificationTone(kind)}catch(e){}},1000)}return ok}
function beep(freq,dur){var ctx=getAudioContext();if(!ctx)return false;try{if(ctx.state==="suspended"&&ctx.resume){var r=ctx.resume();if(r&&r.then){r.then(function(){playBeepNow(freq,dur)}).catch(function(){});return true}}return playBeepNow(freq,dur)}catch(e){return false}}
window.unlockAudio=unlockAudio;
window.beep=beep;
window.testBeep=function(kind){return unlockAudio(function(ok){if(ok)playNotificationNow(kind==='iqamah'?'iqamah':'adzan');});};
function iqamahMinutes(name){var v=parseInt(cfg.iqamah&&cfg.iqamah[name],10);return isFinite(v)&&v>0?v:0}
function checkPreEventBeeps(d){
 try{
  var nowSec=d.getHours()*3600+d.getMinutes()*60+d.getSeconds()+d.getMilliseconds()/1000;
  var dateK=dateKey(d),list=["Subuh","Dzuhur","Ashar","Maghrib","Isya"],i,n,adMin,diff,key,iqSec;
  for(i=0;i<list.length;i++){
   n=list[i];
   if(typeof times[n]!=="string"||times[n].indexOf(":")<0)continue;
   adMin=parseTime(times[n]);
   diff=adMin*60-nowSec;
   if(diff>=0&&diff<=5.25){
    key=dateK+"|ADZAN|"+n;
    if(lastBeepKey!==key){lastBeepKey=key;unlockAudio(function(ok){if(ok)playNotificationNow("adzan");});}
   }
   iqSec=(adMin+iqamahMinutes(n))*60;
   diff=iqSec-nowSec;
   if(diff>=0&&diff<=5.25){
    key=dateK+"|IQAMAH|"+n;
    if(lastBeepKey!==key){lastBeepKey=key;unlockAudio(function(ok){if(ok)playNotificationNow("iqamah");});}
   }
  }
 }catch(e){}
}

function clockText(mins){mins=(mins+1440)%1440;return pad(Math.floor(mins/60))+":"+pad(mins%60)}
var names=["Subuh","Syuruq","Awal Dhuha","Dzuhur","Ashar","Maghrib","Isya"];
function cloneDefaults(){return merge({},defaults)}
function merge(a,b){var o={},k;for(k in (a||{}))o[k]=a[k];for(k in (b||{}))if(k!=="adjust"&&b[k]!==null&&b[k]!==undefined)o[k]=b[k];o.adjust={};for(k in ((a&&a.adjust)||{}))o.adjust[k]=a.adjust[k];for(k in ((b&&b.adjust)||{}))if(b.adjust[k]!==null&&b.adjust[k]!==undefined)o.adjust[k]=b.adjust[k];return o}
function load(){try{return merge(defaults,JSON.parse(localStorage.getItem(KEY)||"{}"))}catch(e){return cloneDefaults()}}
function save(){localStorage.setItem(KEY,JSON.stringify(cfg))}
function pad(n){return n<10?"0"+n:""+n}
function dateKey(d){return d.getFullYear()+"-"+pad(d.getMonth()+1)+"-"+pad(d.getDate())}
function parseTime(s){var p=s.split(":");return parseInt(p[0],10)*60+parseInt(p[1],10)}
function fmtSec(s){s=Math.max(0,Math.floor(s));return pad(Math.floor(s/3600))+":"+pad(Math.floor(s%3600/60))+":"+pad(s%60)}
function esc(s){return String(s||"").replace(/[&<>"]/g,function(c){return{"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]})}
function getTZ(d){return -d.getTimezoneOffset()/60}
function getNode(){return LOC[cfg.province]||LOC.DIY}
function fillSelect(id,items,value){var el=document.getElementById(id),h="",k;for(k in items)h+='<option value="'+esc(k)+'">'+esc(items[k].label||k)+'</option>';el.innerHTML=h;if(value&&items[value])el.value=value}
function setupLocations(){
  // v0.3.84: lokasi sumber jadwal hanya koordinat manual.
  return true;
}
function refreshLocationSelects(){ return true; }
function applyLocation(){ return true; }
function apiLocationKeyword(){return (cfg.regency||"Gunungkidul").replace(/([a-z])([A-Z])/g,"$1 $2")}
function apiDate(d){return d.getFullYear()+"-"+pad(d.getMonth()+1)+"-"+pad(d.getDate())}
function normalizeTime(v){if(!v)return "--:--";var m=String(v).match(/\d{1,2}:\d{2}/);return m?m[0]:"--:--"}
function extractOnline(data){var x=data&&data.data&&data.data.jadwal?data.data.jadwal:(data&&data.data?data.data:null);if(!x)return null;return {Subuh:normalizeTime(x.subuh||x.fajr||x.Fajr),Syuruq:normalizeTime(x.terbit||x.sunrise||x.Sunrise),Dzuhur:normalizeTime(x.dzuhur||x.dhuhr||x.Dhuhr),Ashar:normalizeTime(x.ashar||x.asr||x.Asr),Maghrib:normalizeTime(x.maghrib||x.sunset||x.Sunset),Isya:normalizeTime(x.isya||x.isha||x.Isha)}}
function useOnlineTimes(d,out,source){var m,k;for(k in out){m=parseTime(out[k])+parseInt(cfg.adjust[k]||0,10);m=(m+1440)%1440;out[k]=pad(Math.floor(m/60))+":"+pad(m%60)}m=(parseTime(out.Syuruq)+parseInt(cfg.dhuha||15,10)+1440)%1440;out["Awal Dhuha"]=pad(Math.floor(m/60))+":"+pad(m%60);times=out;lastDate=dateKey(d);onlineState=source||"Online — jadwal tersinkron";var st=document.getElementById("syncStatus");if(st)st.innerHTML=esc(onlineState)}
function setSyncStatus(t){onlineState=t;var st=document.getElementById("syncStatus");if(st)st.innerHTML=esc(t)}
function fetchJSON(url){return fetch(url,{cache:"no-store"}).then(function(r){if(!r.ok)throw new Error("HTTP "+r.status);return r.json()})}
function validPrayerTimes(out){
 try{
  var order=["Subuh","Syuruq","Dzuhur","Ashar","Maghrib","Isya"], prev=-1, i, v;
  for(i=0;i<order.length;i++){
   v=out&&out[order[i]];
   if(typeof v!=="string"||!/^[0-2]?\d:\d\d$/.test(v)||v==="--:--")return false;
   v=parseTime(v);
   if(v<0||v>1439)return false;
   if(i&&v<=prev)return false;
   prev=v;
  }
  return true;
 }catch(e){return false}
}
function extractAladhan(data){
 var t=data&&data.data&&data.data.timings;
 if(!t)return null;
 var out={Subuh:normalizeTime(t.Fajr),Syuruq:normalizeTime(t.Sunrise),Dzuhur:normalizeTime(t.Dhuhr),Ashar:normalizeTime(t.Asr),Maghrib:normalizeTime(t.Maghrib),Isya:normalizeTime(t.Isha)};
 return validPrayerTimes(out)?out:null;
}
function coordCacheKey(dayKey){
  var lat=Number(cfg.lat),lng=Number(cfg.lng);
  return (isFinite(lat)?lat.toFixed(6):"0")+","+(isFinite(lng)?lng.toFixed(6):"0")+"|"+dayKey;
}
function validManualCoordinates(){
  var lat=Number(cfg.lat),lng=Number(cfg.lng);
  return isFinite(lat)&&isFinite(lng)&&lat>=-90&&lat<=90&&lng>=-180&&lng<=180&&(lat!==0||lng!==0);
}
function minutesDiff(a,b){
  var x=Math.abs(parseTime(a)-parseTime(b));
  return Math.min(x,1440-x);
}
function reasonableOnlineTimes(out,d){
  if(!validPrayerTimes(out))return false;
  var p=PrayTimes,base=p.compute(d,parseFloat(cfg.lat),parseFloat(cfg.lng),getTZ(d),cfg.asr),local={Subuh:base.Subuh,Syuruq:base.Syuruq,Dzuhur:base.Dzuhur,Ashar:base.Ashar,Maghrib:base.Maghrib,Isya:base.Isya},k,m;
  for(k in local){m=parseTime(local[k])+parseInt(cfg.adjust[k]||0,10);m=(m+1440)%1440;local[k]=pad(Math.floor(m/60))+":"+pad(m%60);}
  for(k in local){if(minutesDiff(out[k],local[k])>120)return false;}
  return true;
}
function syncOnline(d,quiet){
 if(onlineBusy)return Promise.resolve(false);
 onlineBusy=true;
 var key=apiDate(d), cache=cacheLoad(), cacheKey=coordCacheKey(key);
 if(!quiet)setSyncStatus("Menyinkronkan jadwal berdasarkan koordinat...");
 if(!validManualCoordinates()){ setSyncStatus("Koordinat manual belum valid"); calculate(d); render(); onlineBusy=false; return Promise.resolve(true); }
 var lat=Number(cfg.lat), lon=Number(cfg.lng);
 var dd=d.getDate()+"-"+(d.getMonth()+1)+"-"+d.getFullYear();
 var url="https://api.aladhan.com/v1/timings/"+dd+"?latitude="+encodeURIComponent(lat)+"&longitude="+encodeURIComponent(lon)+"&method=11&school=0&adjustment=0&_\="+Date.now();
 return fetchJSON(url).then(function(resp){
   var out=extractAladhan(resp);
   if(!out||!reasonableOnlineTimes(out,d))throw new Error("Hasil online tidak wajar terhadap koordinat manual");
   cache[cacheKey]={times:out,location:cfg.location||"Koordinat manual",savedAt:new Date().toISOString()};
   cacheSave(cache);
   onlineLastSync=new Date().toLocaleString("id-ID");
   useOnlineTimes(d,out,"Online — Aladhan berdasarkan koordinat masjid");
   render(); return true;
 }).catch(function(){
   setSyncStatus("Offline — jadwal dihitung dari koordinat manual");
   calculate(d); render(); return true;
 }).then(function(ok){onlineBusy=false;return ok},function(){onlineBusy=false;return false});
}
function loadCachedOrCalculate(d){var key=apiDate(d),cache=cacheLoad(),cacheKey=coordCacheKey(key),c=cache[cacheKey];if(c&&c.times&&reasonableOnlineTimes(c.times,d)){useOnlineTimes(d,c.times,"Offline — memakai jadwal tersimpan");return}calculate(d);setSyncStatus("Offline — jadwal lokal darurat")}
function calculate(d){
 var p=PrayTimes,base=p.compute(d,parseFloat(cfg.lat),parseFloat(cfg.lng),getTZ(d),cfg.asr),out={Subuh:base.Subuh,Syuruq:base.Syuruq,Dzuhur:base.Dzuhur,Ashar:base.Ashar,Maghrib:base.Maghrib,Isya:base.Isya},k,m;
 for(k in out){m=parseTime(out[k])+parseInt(cfg.adjust[k]||0,10);m=(m+1440)%1440;out[k]=pad(Math.floor(m/60))+":"+pad(m%60)}
 m=(parseTime(out.Syuruq)+parseInt(cfg.dhuha||15,10)+1440)%1440;out["Awal Dhuha"]=pad(Math.floor(m/60))+":"+pad(m%60);times=out;lastDate=dateKey(d)
}

function openBrandingDB(){
 return new Promise(function(resolve){
  try{
   var req=indexedDB.open("jadwalShalatBranding",1);
   req.onupgradeneeded=function(){if(!req.result.objectStoreNames.contains("branding"))req.result.createObjectStore("branding",{keyPath:"id"})};
   req.onsuccess=function(){brandingDb=req.result;resolve(true)};
   req.onerror=function(){resolve(false)};
  }catch(e){resolve(false)}
 });
}
function loadBranding(){
 return new Promise(function(resolve){
  if(!brandingDb)return resolve("");
  try{var req=brandingDb.transaction("branding","readonly").objectStore("branding").get("main");req.onsuccess=function(){resolve(req.result&&req.result.image||"")};req.onerror=function(){resolve("")}}
  catch(e){resolve("")}
 });
}
function saveBranding(image){
 return new Promise(function(resolve){
  if(!brandingDb)return resolve(false);
  try{var req=brandingDb.transaction("branding","readwrite").objectStore("branding").put({id:"main",image:image,updatedAt:Date.now()});req.onsuccess=function(){resolve(true)};req.onerror=function(){resolve(false)}}catch(e){resolve(false)}
 });
}
function setLogoSource(src){
 brandingImage=src||"";
 var img=document.getElementById("logoImage"),prev=document.getElementById("logoPreview");
 if(img)img.src=brandingImage||DEFAULT_LOGO;
 if(prev)prev.src=brandingImage||DEFAULT_LOGO;
}
function autoAdaptLogo(file){
 return new Promise(function(resolve,reject){
  var reader=new FileReader(); reader.onerror=reject; reader.onload=function(){
   var image=new Image(); image.onload=function(){
    try{
     var w=image.naturalWidth||image.width,h=image.naturalHeight||image.height,cv=document.createElement("canvas"),ctx=cv.getContext("2d");
     var probe=document.createElement("canvas"),pw=Math.min(320,w),ph=Math.max(1,Math.round(h*pw/w)),pc=probe.getContext("2d"); probe.width=pw;probe.height=ph;pc.drawImage(image,0,0,pw,ph);
     var data=pc.getImageData(0,0,pw,ph).data,minX=pw,minY=ph,maxX=-1,maxY=-1,x,y,idx,r,g,b,a;
     for(y=0;y<ph;y++)for(x=0;x<pw;x++){idx=(y*pw+x)*4;r=data[idx];g=data[idx+1];b=data[idx+2];a=data[idx+3];if(a>12 && !(r>245&&g>245&&b>245)){if(x<minX)minX=x;if(x>maxX)maxX=x;if(y<minY)minY=y;if(y>maxY)maxY=y}}
     if(maxX<0){minX=0;minY=0;maxX=pw-1;maxY=ph-1}
     var sx=w/pw,sy=h/ph;minX=Math.max(0,Math.floor(minX*sx));maxX=Math.min(w-1,Math.ceil((maxX+1)*sx));minY=Math.max(0,Math.floor(minY*sy));maxY=Math.min(h-1,Math.ceil((maxY+1)*sy));
     var bw=maxX-minX+1,bh=maxY-minY+1,pad=Math.round(Math.max(bw,bh)*.10);minX=Math.max(0,minX-pad);minY=Math.max(0,minY-pad);maxX=Math.min(w-1,maxX+pad);maxY=Math.min(h-1,maxY+pad);bw=maxX-minX+1;bh=maxY-minY+1;
     cv.width=512;cv.height=512;ctx.clearRect(0,0,512,512);var scale=Math.min(460/bw,460/bh),dw=bw*scale,dh=bh*scale;ctx.drawImage(image,minX,minY,bw,bh,(512-dw)/2,(512-dh)/2,dw,dh);resolve(cv.toDataURL("image/webp",.86));
    }catch(e){reject(e)}
   }; image.onerror=reject; image.src=reader.result;
  }; reader.readAsDataURL(file);
 });
}
function resetLogo(){brandingImage="";saveBranding("").then(function(){setLogoSource("")})}

/* Remote slideshow uses cfg.slideUrls; local image slideshow uses IndexedDB. */

function fitInfoMessage(){
  const el=document.getElementById("infoMessage");
  if(!el) return;
  // Jangan beri tinggi 100% pada teks karena dapat memperbesar grid/panel.
  el.style.setProperty("height","auto","important");
  el.style.setProperty("min-height","0","important");
  el.style.setProperty("max-height","none","important");
  el.style.setProperty("overflow","hidden","important");
  el.style.setProperty("line-height","1.16","important");
  el.style.setProperty("box-sizing","border-box","important");

  // Ukur ruang aktual yang disediakan flex/grid parent.
  const available=Math.max(1, el.clientHeight);
  let size=30;
  const minSize=10;
  let guard=0;
  while(guard++<50){
    el.style.setProperty("font-size",size+"px","important");
    void el.offsetHeight;
    if(el.scrollHeight <= available + 1) break;
    size-=1;
    if(size<=minSize){
      size=minSize;
      el.style.setProperty("font-size",size+"px","important");
      break;
    }
  }
  el.dataset.fittedSize=String(size);
}
function scheduleInfoFit(){
  requestAnimationFrame(function(){
    fitInfoMessage();
    setTimeout(fitInfoMessage,120);
  });
}

function renderSlideList(){
 var el=document.getElementById("slideList"); if(!el)return;
 if(!slides.length){el.innerHTML='<div class="note">Belum ada URL YouTube autoplay.</div>';return}
 el.innerHTML=slides.map(function(s,idx){
  return '<div class="slide-item"><span>YouTube '+(idx+1)+'</span><button type="button" data-del-slide="'+esc(s.id)+'">Hapus</button></div>';
 }).join("");
 /* Remote slide entries are read-only here; they are managed in Admin.
    The previous handler referenced removed dbDel/dbAll functions. */
}
var youtubeApiPromise=null;
function loadYouTubeIframeApi(){
 if(window.YT&&window.YT.Player)return Promise.resolve(window.YT);
 if(youtubeApiPromise)return youtubeApiPromise;
 youtubeApiPromise=new Promise(function(resolve,reject){
  var old=window.onYouTubeIframeAPIReady;
  window.onYouTubeIframeAPIReady=function(){try{if(typeof old==='function')old()}catch(e){} if(window.YT&&window.YT.Player)resolve(window.YT);else reject(new Error('YouTube API tidak tersedia'))};
  var existing=document.querySelector('script[src*="youtube.com/iframe_api"]');
  if(existing){
   var tries=0;(function wait(){if(window.YT&&window.YT.Player)return resolve(window.YT);if(++tries>100)return reject(new Error('YouTube API timeout'));setTimeout(wait,100)})();
   return;
  }
  var script=document.createElement('script'); script.src='https://www.youtube.com/iframe_api'; script.async=true; script.onload=function(){}; script.onerror=function(){reject(new Error('Gagal memuat YouTube API'))}; document.head.appendChild(script);
 });
 return youtubeApiPromise;
}
function youtubeId(raw){
 raw=String(raw||'').trim(); if(!raw)return '';
 try{
  var u=new URL(raw,location.href), host=(u.hostname||'').toLowerCase();
  if(host==='youtu.be'||host.endsWith('.youtu.be'))return (u.pathname.split('/').filter(Boolean)[0]||'').split(/[?&#]/)[0];
  if(host.indexOf('youtube.com')>=0||host.indexOf('youtube-nocookie.com')>=0){
   var q=u.searchParams.get('v'); if(q)return q;
   var m=u.pathname.match(/\/(?:embed|shorts|live|v)\/([^/?&#]+)/); if(m)return m[1];
  }
 }catch(e){}
 var m=raw.match(/[?&]v=([A-Za-z0-9_-]{6,})/); if(m)return m[1];
 m=raw.match(/youtu\.be\/([A-Za-z0-9_-]{6,})/); if(m)return m[1];
 m=raw.match(/youtube(?:-nocookie)?\.com\/(?:embed|shorts|live|v)\/([A-Za-z0-9_-]{6,})/); return m?m[1]:'';
}
function normalizeSlideUrl(raw){
 var id=youtubeId(raw); if(!id)return '';
 /* APK memakai HTML lokal. YouTube dipanggil melalui bridge HTTPS agar WebView
    tidak mengirim request langsung dari origin lokal (penyebab Error 153). */
 return 'https://shalatku.pages.dev/youtube-player.html?v='+encodeURIComponent(id)+'&bridge=controls1';
}
function normalizeSlideUrls(value){
 var arr=Array.isArray(value)?value:String(value||'').split(/[\r\n,]+/);
 return arr.map(function(v){return typeof v==='object'?(v.url||v.youtube||v.link||''):v;}).map(normalizeSlideUrl).filter(Boolean);
}
var youtubePlayer=null, youtubePlayerGeneration=0, youtubePollTimer=null;
var networkProbeTimer=null, networkProbeBusy=false, youtubeOfflineLocked=false;
function forceScheduleOnOffline(){
 youtubeOfflineLocked=true; slideshowSuppressed=true; cleanupYouTubePlayer();
 var frame=document.getElementById("slideYoutube"); if(frame){try{frame.src="about:blank";}catch(e){} try{frame.removeAttribute("src");}catch(e){} try{frame.style.visibility="hidden";frame.style.opacity="0";}catch(e){}}
 var el=document.getElementById("slideshow"); if(el){el.classList.add("hidden");try{el.style.visibility="hidden";el.style.opacity="0";el.style.pointerEvents="none";}catch(e){}}
 var stage=document.getElementById("tvStage"); if(stage)stage.classList.remove("slideshow-mode","slideshow-local-mode","slideshow-remote-mode");
 var display=document.getElementById("display"); if(display){display.classList.remove("hidden");try{display.style.visibility="visible";display.style.opacity="1";display.style.pointerEvents="auto";}catch(e){}}
}
function restoreFromOnline(){
 if(navigator.onLine===false)return;
 var wasOfflineState=!!(youtubeOfflineLocked||slideshowSuppressed);
 if(!wasOfflineState)return;
 youtubeOfflineLocked=false;
 slideshowSuppressed=false;
 slideshowModeNow="";
 var el=document.getElementById("slideshow");
 if(el){el.classList.add("hidden");try{el.style.visibility="hidden";el.style.opacity="0";el.style.pointerEvents="none";}catch(e){}}
 var display=document.getElementById("display");
 if(display){display.classList.remove("hidden");try{display.style.visibility="visible";display.style.opacity="1";display.style.pointerEvents="auto";}catch(e){}}
 try{updateSlideshow(new Date());}catch(e){}
 try{syncOnline(new Date(),false);}catch(e){}
}
function probeInternetReachability(){
 if(networkProbeBusy)return;
 if(navigator.onLine===false){forceScheduleOnOffline();return;}
 networkProbeBusy=true; var done=false;
 function finish(ok){
  if(done)return; done=true; networkProbeBusy=false;
  if(ok)restoreFromOnline(); else forceScheduleOnOffline();
 }
 var timer=setTimeout(function(){finish(false);},3500);
 /* Use a network request rather than an image load. Some Android WebViews
    report image onerror even when connectivity has already returned. */
 try{
  fetch('https://www.youtube.com/favicon.ico?jadwal_shalat_net='+Date.now(),{method:'HEAD',mode:'no-cors',cache:'no-store'})
   .then(function(){clearTimeout(timer);finish(true);})
   .catch(function(){clearTimeout(timer);finish(false);});
 }catch(e){clearTimeout(timer);finish(false);}
}
function startNetworkProbe(){
 if(networkProbeTimer)clearInterval(networkProbeTimer);
 networkProbeTimer=setInterval(function(){
  var enabled=cfg.slideEnabled===true||String(cfg.slideEnabled)==="true";
  /* Keep probing while an offline lock exists, even if cloud config changed
     the slideshow flag during the offline period. */
  if(enabled||youtubeOfflineLocked||slideshowSuppressed)probeInternetReachability();
 },2000);
}

function cleanupYouTubePlayer(){if(youtubePollTimer){clearTimeout(youtubePollTimer);youtubePollTimer=null} if(youtubePlayer){try{youtubePlayer.destroy()}catch(e){} youtubePlayer=null}}
function localSlideshowEnabled(){
 /* Local slideshow is a device-only toggle. It must not be overridden by
    the remote Admin field, otherwise a remote false value makes the APK
    checkbox appear unable to activate the local slideshow. */
 try{return localStorage.getItem('jadwalShalatLocalSlidesEnabled')==='true';}
 catch(e){return false;}
}
function setLocalSlideshowEnabled(v){
 try{localStorage.setItem('jadwalShalatLocalSlidesEnabled',v?'true':'false');}catch(e){}
}
function remoteVideoActive(now){
 /* Video Admin hanya mengikuti jadwal mingguan/hari dan jam yang dipilih.
    slideAfter/slideBefore TIDAK berlaku untuk video remote. */
 return (cfg.slideEnabled===true || String(cfg.slideEnabled)==='true') && slides.length>0 && slideScheduleAllows(now);
}
function localVideoActive(){return localSlideshowEnabled() && localSlides.length>0;}
function showSlide(index){
 var frame=document.getElementById('slideYoutube'),img=document.getElementById('slideLocalImage');
 if(!frame||!img)return;
 var now=new Date();
 var useRemote=remoteVideoActive(now);
 var useLocal=!useRemote&&localVideoActive();
 localSlideMode=useLocal;
 if(useLocal){
  cleanupYouTubePlayer();
  frame.removeAttribute('src');frame.style.display='none';frame.style.visibility='hidden';frame.style.opacity='0';
  img.style.display='block';img.style.visibility='visible';img.style.opacity='1';
  img.src=localSlides[index%localSlides.length].dataUrl;
  return;
 }
 if(!useRemote||youtubeOfflineLocked||navigator.onLine===false){
  cleanupYouTubePlayer();
  frame.removeAttribute('src');frame.style.display='none';frame.style.visibility='hidden';frame.style.opacity='0';
  img.removeAttribute('src');img.style.display='none';img.style.visibility='hidden';img.style.opacity='0';
  return;
 }
 localSlideMode=false;img.removeAttribute('src');img.style.display='none';img.style.visibility='hidden';img.style.opacity='0';
 var item=slides[index%slides.length];cleanupYouTubePlayer();
 frame.style.setProperty('display','block','important');frame.style.setProperty('visibility','visible','important');frame.style.setProperty('opacity','1','important');frame.style.setProperty('z-index','2200','important');
 frame.setAttribute('allow','autoplay; encrypted-media; picture-in-picture; fullscreen');frame.setAttribute('allowfullscreen','true');
 var src=item.youtube||item.image||'';if(!src)return;frame.removeAttribute('src');frame.src=src;
}
function slideScheduleAllows(now){
 try{
  /* Jadwal mingguan adalah aturan wajib untuk video Admin.
     Nilai lama slideScheduleEnabled=false tidak boleh membypass jadwal. */
  var days=Array.isArray(cfg.slideScheduleDays)?cfg.slideScheduleDays.map(function(x){return Number(x)}):[0,1,2,3,4,5,6];
  if(!days.length)return false;
  if(days.indexOf(now.getDay())<0)return false;
  function mins(v,def){var m=/^(\d{1,2}):(\d{2})$/.exec(String(v||""));if(!m)return def;return Math.max(0,Math.min(1439,Number(m[1])*60+Number(m[2])));}
  var cur=now.getHours()*60+now.getMinutes();
  var start=mins(cfg.slideScheduleStart,0),end=mins(cfg.slideScheduleEnd,1439);
  if(start===end)return true;
  if(start<end)return cur>=start&&cur<=end;
  return cur>=start||cur<=end;
 }catch(e){return true;}
}
function localSlideshowWindowActive(now){
 /* Jeda setelah iqamah dan sebelum adzan hanya berlaku untuk gambar lokal TV. */
 var cur=now instanceof Date ? (now.getHours()*60+now.getMinutes()+now.getSeconds()/60) : Number(now)||0;
 var wajib=['Subuh','Dzuhur','Ashar','Maghrib','Isya'],prev=null,next=null,i;
 for(i=0;i<wajib.length;i++){
  var ad=parseTime(times[wajib[i]]||'00:00');
  if(ad<=cur)prev={n:wajib[i],ad:ad};
  else if(!next)next={n:wajib[i],ad:ad};
 }
 if(!prev)prev={n:'Isya',ad:parseTime(times.Isya||'00:00')-1440};
 if(!next)next={n:'Subuh',ad:parseTime(times.Subuh||'00:00')+1440};
 var start=prev.ad+iqamahMinutes(prev.n)+Number(cfg.slideAfter==null?15:cfg.slideAfter);
 var stop=next.ad-Number(cfg.slideBefore==null?15:cfg.slideBefore);
 var current=cur;
 if(current<start)current+=1440;
 return current>=start && current<stop;
}
function slideshowActive(now){
 var hasRemote=remoteVideoActive(now);
 var hasLocal=localVideoActive() && localSlideshowWindowActive(now);
 return hasRemote || hasLocal;
}
var slideshowHistoryActive=false;
var slideshowSuppressed=false;
var slideshowModeNow="";
function ensureBackGuard(){
 try{
  if(!history.state || !history.state.__jadwalShalatBase){
   history.replaceState(Object.assign({},history.state||{},{__jadwalShalatBase:true}),document.title,location.href);
  }
 }catch(_){}
}
function enterSlideshowView(mode){
 try{
  var stage=document.getElementById("tvStage");
  if(stage){
   stage.classList.remove("slideshow-mode","slideshow-local-mode","slideshow-remote-mode");
   if(mode==='local')stage.classList.add('slideshow-local-mode');
   else if(mode==='remote')stage.classList.add('slideshow-mode','slideshow-remote-mode');
  }
  if(!slideshowHistoryActive){
   history.pushState({__jadwalShalatSlideshow:true},"",location.href.split("#")[0]+"#slideshow");
   slideshowHistoryActive=true;
  }
 }catch(_){}
}
function hideSlideshowNow(){
 var stage=document.getElementById("tvStage"); if(stage)stage.classList.remove("slideshow-mode","slideshow-local-mode","slideshow-remote-mode");
 var el=document.getElementById("slideshow");
 if(el){el.classList.add("hidden");try{el.style.visibility="hidden";el.style.opacity="0";el.style.pointerEvents="none";}catch(e){}}
 if(slideTimer){clearInterval(slideTimer);slideTimer=null;}
 if(slideshowHistoryActive){
  slideshowHistoryActive=false;
  try{
   if(location.hash==="#slideshow"){
    history.replaceState({__jadwalShalatBase:true},document.title,location.href.split("#")[0]);
   }
  }catch(_){}
 }
}
function positionLocalSlideshow(){
 try{
  var stage=document.getElementById('tvStage'),hero=document.querySelector('#display .schedule-panel > .hero'),el=document.getElementById('slideshow');
  if(!stage||!hero||!el)return;
  var sr=stage.getBoundingClientRect(),hr=hero.getBoundingClientRect();
  el.style.setProperty('left',(hr.left-sr.left)+'px','important');
  el.style.setProperty('top',(hr.top-sr.top)+'px','important');
  el.style.setProperty('width',hr.width+'px','important');
  el.style.setProperty('height',hr.height+'px','important');
  el.style.setProperty('right','auto','important');
  el.style.setProperty('bottom','auto','important');
 }catch(e){}
}
function updateSlideshow(now){
 var el=document.getElementById("slideshow"); if(!el)return;
 /* Callers historically passed either minutes or a Date. Normalize here so
    weekly remote-video rules always receive a real Date object. */
 var currentDate=now instanceof Date?now:new Date();
 var active=slideshowActive(currentDate);
 if(youtubeOfflineLocked){if(!active){youtubeOfflineLocked=false;}else{if(!el.classList.contains("hidden"))hideSlideshowNow();return;}}
 if(navigator.onLine===false && slides.length){if(!localSlides.length){forceScheduleOnOffline();return;} /* Local images remain available offline. */}
 if(slideshowSuppressed){
  if(!active)slideshowSuppressed=false;
  else { if(!el.classList.contains("hidden"))hideSlideshowNow(); return; }
 }
 if(active){
  /* Clear inline hidden state left by hideSlideshowNow before selecting the mode. */
  el.style.setProperty('visibility','visible','important');
  el.style.setProperty('opacity','1','important');
  el.style.setProperty('pointer-events','auto','important');
  if(el.classList.contains("hidden")){
   el.classList.remove("hidden"); slideIndex=0; showSlide(0); enterSlideshowView(remoteVideoActive(currentDate)?"remote":"local");
  }
  var remoteNow=remoteVideoActive(currentDate);
  var localNow=!remoteNow&&localVideoActive()&&localSlideshowWindowActive(currentDate);
  if(remoteNow){
   /* Clear geometry previously written for the local hero overlay.
      Inline !important values otherwise keep YouTube trapped in the hero. */
   ['left','top','width','height','right','bottom'].forEach(function(prop){try{el.style.removeProperty(prop);}catch(e){}});
   el.style.setProperty('position','absolute','important');
   el.style.setProperty('inset','0','important');
   el.style.setProperty('width','100%','important');
   el.style.setProperty('height','100%','important');
  }
  var nextMode=remoteNow?'remote':(localNow?'local':'');
  var modeChanged=slideshowModeNow!==nextMode;
  if(modeChanged){
   slideshowModeNow=nextMode;
   slideIndex=0;
   if(slideTimer){clearInterval(slideTimer);slideTimer=null;}
   showSlide(0);
  }
  enterSlideshowView(nextMode);
  if(localNow)positionLocalSlideshow();
  var activeSlideCount=remoteNow?slides.length:(localNow?localSlides.length:0);
  if(!slideTimer && activeSlideCount>1){
   slideTimer=setInterval(function(){
    /* Always evaluate the real current time. The previous closure captured
       the time from the first activation, so remote expiry could leave the
       player stuck until a manual sync/reload. */
    var tickDate=new Date();
    updateSlideshow(tickDate);
    var remoteTick=remoteVideoActive(tickDate);
    var localTick=!remoteTick&&localVideoActive()&&localSlideshowWindowActive(tickDate);
    var countNow=remoteTick?slides.length:(localTick?localSlides.length:0);
    if(countNow>1){
     slideIndex=(slideIndex+1)%countNow;
     showSlide(slideIndex);
    }
   },Math.max(3,Number(cfg.slideDuration||15))*1000);
  }
 }else{
  if(!el.classList.contains("hidden"))hideSlideshowNow();
 }
}
/* Cloud config application: update the running display without reload/flicker. */
window.applyJadwalCloudConfig=function(remote){
 try{
  if(!remote||typeof remote!=='object')return;
  cfg=merge(merge(defaults,cfg||{}),remote);
  normalizeIqamahConfig();
  save();

  /* Rebuild remote slideshow data immediately. Previously slideUrls and
     slideEnabled changed in cloud but the in-memory `slides` array stayed
     on the values loaded at boot, so Sync appeared successful while the
     APK continued showing the old video list. */
  var remoteUrls=cfg.slideUrls||cfg.youtubeUrls||cfg.youtube||cfg.slides||cfg.slideUrlsText||[];
  if(typeof normalizeSlideUrls==='function'){
    slides=normalizeSlideUrls(remoteUrls).map(function(u,i){
      return {id:'remote-'+i,youtube:u,order:i+1,remote:true};
    });
  }
  if(slideTimer){clearInterval(slideTimer);slideTimer=null;}
  slideIndex=0;
  calculate(new Date());
  render();
  renderSlideList();
  var t=document.getElementById('localSlideEnabled');
  if(t)t.checked=localSlideshowEnabled();
  var d=new Date();
  updateSlideshow(d.getHours()*60+d.getMinutes()+d.getSeconds()/60);
  if(typeof startNetworkProbe==='function')startNetworkProbe();
 }catch(e){try{console.warn('[JADWAL SHALAT] cloud apply failed',e);}catch(_){} }
};
/* Local slideshow: images are stored only on this Android TV device. */
var LOCAL_DB='jadwalShalatLocalSlides_v1';
function localDb(){return new Promise(function(resolve,reject){if(!window.indexedDB)return reject(new Error('IndexedDB tidak tersedia'));var r=indexedDB.open(LOCAL_DB,1);r.onupgradeneeded=function(){if(!r.result.objectStoreNames.contains('images'))r.result.createObjectStore('images',{keyPath:'id',autoIncrement:true});};r.onsuccess=function(){resolve(r.result)};r.onerror=function(){reject(r.error||new Error('DB gagal'))};});}
function localAll(){return localDb().then(function(db){return new Promise(function(resolve,reject){var tx=db.transaction('images','readonly'),out=[],req=tx.objectStore('images').openCursor();req.onsuccess=function(e){var c=e.target.result;if(c){out.push(c.value);c.continue();}else{out.sort(function(a,b){return Number(a.order||a.createdAt||a.id)-Number(b.order||b.createdAt||b.id);});resolve(out);}};req.onerror=function(){reject(req.error)};});});}
function localClear(){return localDb().then(function(db){return new Promise(function(resolve,reject){var tx=db.transaction('images','readwrite');tx.objectStore('images').clear();tx.oncomplete=resolve;tx.onerror=function(){reject(tx.error)};});});} function localDelete(id){return localDb().then(function(db){return new Promise(function(resolve,reject){var tx=db.transaction('images','readwrite');tx.objectStore('images').delete(Number(id));tx.oncomplete=resolve;tx.onerror=function(){reject(tx.error)};});});}
function localAdd(files){return localDb().then(function(db){return localAll().then(function(existing){var base=existing.length?Math.max.apply(null,existing.map(function(x){return Number(x.order||0);}))+1:0;return Promise.all(Array.prototype.map.call(files,function(file,i){return new Promise(function(resolve,reject){var fr=new FileReader();fr.onload=function(){var tx=db.transaction('images','readwrite');tx.objectStore('images').add({name:file.name,dataUrl:fr.result,createdAt:Date.now(),order:base+i});tx.oncomplete=resolve;tx.onerror=function(){reject(tx.error)};};fr.onerror=reject;fr.readAsDataURL(file);});}));});});}
function escLocalText(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
function localPutAll(items){return localDb().then(function(db){return new Promise(function(resolve,reject){var tx=db.transaction('images','readwrite'),store=tx.objectStore('images');items.forEach(function(item,i){item.order=i;store.put(item);});tx.oncomplete=resolve;tx.onerror=function(){reject(tx.error)};});});}
function renderLocalSlideList(){
 var box=document.getElementById('localSlideList');if(!box)return;
 if(!localSlides.length){box.innerHTML='<div class="note">Belum ada gambar tersimpan.</div>';return;}
 box.innerHTML='<div style="font-weight:bold;margin-bottom:6px">Urutan tayang ('+localSlides.length+')</div>'+localSlides.map(function(item,i){
  return '<div data-local-row="'+item.id+'" style="display:flex;align-items:center;gap:6px;margin:5px 0;padding:7px;border:1px solid rgba(255,255,255,.18);border-radius:6px;flex-wrap:wrap">'+
  '<span style="flex:1;min-width:120px;overflow-wrap:anywhere">'+(i+1)+'. '+escLocalText(item.name||('Gambar '+(i+1)))+'</span>'+
  '<button type="button" data-local-up="'+item.id+'" '+(i===0?'disabled':'')+'>↑</button>'+
  '<button type="button" data-local-down="'+item.id+'" '+(i===localSlides.length-1?'disabled':'')+'>↓</button>'+
  '<button type="button" data-local-delete="'+item.id+'" title="Hapus gambar" aria-label="Hapus gambar '+(i+1)+'">🗑 Hapus</button></div>';
 }).join('');
 box.querySelectorAll('[data-local-up],[data-local-down],[data-local-delete]').forEach(function(btn){
  btn.onclick=function(){
   var id=Number(btn.getAttribute('data-local-up')||btn.getAttribute('data-local-down')||btn.getAttribute('data-local-delete'));
   var pos=localSlides.findIndex(function(x){return Number(x.id)===id;});
   if(pos<0)return;
   if(btn.hasAttribute('data-local-delete')){
    if(!window.confirm('Hapus gambar ini dari slideshow?'))return;
    var removed=localSlides[pos];
    localSlides.splice(pos,1);
    localDelete(removed.id).then(function(){
      return localPutAll(localSlides);
    }).then(loadLocalSlides).then(function(){
      renderLocalSlideList();
      try{updateSlideshow(new Date());}catch(e){}
    }).catch(function(e){
      localSlides.splice(pos,0,removed);
      renderLocalSlideList();
    });
    return;
   } else {
    var target=btn.hasAttribute('data-local-up')?pos-1:pos+1;
    if(target>=0&&target<localSlides.length){
      var tmp=localSlides[pos];localSlides[pos]=localSlides[target];localSlides[target]=tmp;
    }
   }
   localPutAll(localSlides).then(loadLocalSlides).then(function(){renderLocalSlideList();});
  };
 });
}
function loadLocalSlides(){return localAll().then(function(x){localSlides=x||[];renderLocalSlideList();return localSlides;}).catch(function(){localSlides=[];renderLocalSlideList();return localSlides;});}
function bindLocalSlideControls(){
 var files=document.getElementById('localSlideFiles'),saveBtn=document.getElementById('saveLocalSlides'),clearBtn=document.getElementById('clearLocalSlides'),statusEl=document.getElementById('localSlideStatus'),selectionEl=document.getElementById('localSlideSelection'),toggle=document.getElementById('localSlideEnabled');
 if(!files||!saveBtn||!clearBtn)return;
 var pendingFiles=[];
 function refreshPending(){var list=pendingFiles.map(function(f,i){return (i+1)+'. '+f.name;});if(selectionEl)selectionEl.textContent=list.length?'Antrean '+list.length+' gambar: '+list.join(' | '):'Belum ada gambar dipilih.';}
 function resetInput(el){try{if(el)el.value='';}catch(e){}}
 function addChosen(list){Array.prototype.slice.call(list||[]).forEach(function(file){if(!file||!/^image\//i.test(file.type||''))return;var duplicate=pendingFiles.some(function(old){return old.name===file.name&&old.size===file.size&&old.lastModified===file.lastModified;});if(!duplicate)pendingFiles.push(file);});refreshPending();if(statusEl)statusEl.textContent=pendingFiles.length+' gambar dalam antrean. Tekan Simpan atau pilih Tambah Lagi.';}
 files.onchange=function(){addChosen(files.files);resetInput(files);};
 if(toggle){toggle.checked=localSlideshowEnabled();toggle.onchange=function(){
  var enabled=!!toggle.checked;
  setLocalSlideshowEnabled(enabled);
  if(!enabled){
    localSlideMode=false;
    try{hideSlideshowNow();}catch(e){}
    slideshowSuppressed=true;
  }else{
    slideshowSuppressed=false;
  }
  if(statusEl)statusEl.textContent=enabled?'Slideshow lokal diaktifkan.':'Slideshow lokal dinonaktifkan.';
  render();
  updateSlideshow(new Date());
  if(!enabled){
    var display=document.getElementById('display');
    if(display){display.classList.remove('hidden');display.style.visibility='visible';display.style.opacity='1';display.style.pointerEvents='auto';}
    var stage=document.getElementById('tvStage');if(stage)stage.classList.remove('slideshow-mode');
  }
};}
 saveBtn.onclick=function(){if(!pendingFiles.length){if(statusEl)statusEl.textContent='Pilih minimal satu gambar.';return;}var batch=pendingFiles.slice(),count=batch.length;localAdd(batch).then(loadLocalSlides).then(function(){if(statusEl)statusEl.textContent=count+' gambar berhasil disimpan. Total: '+localSlides.length;pendingFiles=[];resetInput(files);refreshPending();renderLocalSlideList();if(toggle&&!toggle.checked){toggle.checked=true;setLocalSlideshowEnabled(true);if(statusEl)statusEl.textContent+=' Slideshow lokal otomatis diaktifkan.';}render();updateSlideshow(new Date());}).catch(function(e){if(statusEl)statusEl.textContent='Gagal menyimpan gambar: '+(e.message||e);});};
 clearBtn.onclick=function(){pendingFiles=[];resetInput(files);refreshPending();localClear().then(loadLocalSlides).then(function(){if(statusEl)statusEl.textContent='Semua gambar lokal dihapus.';renderLocalSlideList();updateSlideshow(new Date());}).catch(function(e){if(statusEl)statusEl.textContent='Gagal menghapus gambar: '+(e.message||e);});};
 refreshPending();renderLocalSlideList();
}
function render(){setLogoSource(brandingImage);document.getElementById("mosqueName").innerHTML=esc(cfg.name);document.getElementById("mosqueLocation").innerHTML=esc(cfg.location||cfg.village);var rt=document.getElementById("runningText");if(rt){var runningMessage=esc(cfg.running||"");rt.innerHTML='<div class="running-track"><span class="running-item">'+runningMessage+'</span><span class="running-item">'+runningMessage+'</span></div>';}if(rt){var sec=Math.max(5,Math.min(120,Number(cfg.runningSpeed)||28));rt.style.setProperty("--running-speed",sec+"s");rt.style.setProperty("animation-duration",sec+"s","important");rt.style.animationName="none";void rt.offsetWidth;rt.style.animationName="runningTicker";}var st=document.getElementById("syncStatus");if(st)st.innerHTML=esc(onlineState);var h="",i,n;for(i=0;i<names.length;i++){n=names[i];h+='<div class="prayer" id="p-'+i+'"><div class="pname">'+n.toUpperCase()+'</div><div class="ptime">'+(times[n]||"--:--")+'</div></div>'}document.getElementById("prayerGrid").innerHTML=h;var cb=document.getElementById("cashBalance");if(cb)cb.innerHTML="Rp "+Number(cfg.cash||0).toLocaleString("id-ID");var msg=document.getElementById("infoMessage");if(msg){msg.innerHTML=esc(cfg.info||"");scheduleInfoFit();}var note=document.getElementById("infoNote");if(note)note.innerHTML=esc(cfg.note||"")}
function update(){
 var d=new Date(); checkPreEventBeeps(d);
 var now=d.getHours()*60+d.getMinutes()+d.getSeconds()/60; updateSlideshow(now);
 var i,f=null,iq=null;
 if(dateKey(d)!==lastDate){loadCachedOrCalculate(d);render()}
 var clock=document.getElementById("clock"),dateEl=document.getElementById("dateText");
 if(clock)clock.innerHTML=pad(d.getHours())+":"+pad(d.getMinutes())+":"+pad(d.getSeconds());
 if(dateEl)dateEl.innerHTML=d.toLocaleDateString("id-ID",{weekday:"long",year:"numeric",month:"long",day:"numeric"});
 var wajib=["Subuh","Dzuhur","Ashar","Maghrib","Isya"], valid=[];
 for(i=0;i<wajib.length;i++){
   var wn=wajib[i],raw=times[wn];
   if(typeof raw!=="string"||!/^[0-2]?\d:\d\d$/.test(raw))continue;
   var ad=parseTime(raw),iqEnd=ad+iqamahMinutes(wn),prayerEnd=iqEnd+15;
   var deltaAd=ad-now,deltaIq=iqEnd-now;
   // Sebelum iqamah: tampilkan hitung mundur menuju iqamah.
   if(deltaAd<=0&&deltaIq>0){iq={n:wn,remaining:deltaIq*60,iqEnd:iqEnd};break}
   // Setelah iqamah: tandai shalat berlangsung selama 15 menit.
   if(now>=iqEnd&&now<prayerEnd)valid.push({n:wn,ad:ad,iqEnd:iqEnd,i:names.indexOf(wn)});
 }
 if(iq){
   f={n:iq.n,i:names.indexOf(iq.n)};
   document.getElementById("statusLabel").innerHTML="MENUJU IQAMAH<span class=\"dots\">...</span>";
   document.getElementById("nextName").innerHTML=iq.n.toUpperCase();
   document.getElementById("countdown").innerHTML=fmtSec(iq.remaining);
   document.getElementById("statusSub").innerHTML="Iqamah pukul "+clockText(iq.iqEnd);
   var sec=Math.ceil(iq.remaining);
 }else{
   var current=valid.length?valid[valid.length-1]:null;
   if(current){
     f=current;
     document.getElementById("statusLabel").innerHTML="SUDAH MASUK WAKTU SHALAT";
     document.getElementById("nextName").innerHTML=current.n.toUpperCase();
     document.getElementById("countdown").innerHTML="00:00:00";
     document.getElementById("statusSub").innerHTML="Pukul "+times[current.n];
   }else{
     var next=null;
     for(i=0;i<names.length;i++){
       var val=times[names[i]];
       if(typeof val!=="string"||val.indexOf(":")<0)continue;
       var mins=parseTime(val),delta=mins-now;
       if(delta>0&&!next)next={n:names[i],mins:mins,i:i,delta:delta};
     }
     if(!next&&typeof times.Subuh==="string"&&times.Subuh.indexOf(":")>=0)next={n:"Subuh",mins:parseTime(times.Subuh)+1440,i:0,delta:parseTime(times.Subuh)+1440-now};
     f=next||{n:"-",i:-1,delta:0};
     document.getElementById("statusLabel").innerHTML="MENUJU SHALAT<span class=\"dots\">...</span>";
     document.getElementById("nextName").innerHTML=f.n.toUpperCase();
     document.getElementById("countdown").innerHTML=fmtSec((f.delta||0)*60);
     document.getElementById("statusSub").innerHTML=f.n!=="-"?"Pukul "+times[f.n]:"";
   }
 }
 for(i=0;i<7;i++){var el=document.getElementById("p-"+i);if(el)el.className="prayer"+(i===f.i?" active":"")}
}
function enterDisplayModeFullscreen(){
 try{
  if(!document.fullscreenElement){
   var target=document.documentElement;
   if(target&&target.requestFullscreen){
    var promise=target.requestFullscreen({navigationUI:"hide"});
    if(promise&&promise.catch)promise.catch(function(error){
     try{console.warn("[JADWAL SHALAT] Fullscreen ditolak browser:",error);}catch(_){}
    });
   }else if(document.webkitFullscreenElement===undefined&&target&&target.webkitRequestFullscreen){
    target.webkitRequestFullscreen();
   }
  }
  if(screen.orientation&&screen.orientation.lock&&document.fullscreenElement){
   try{
    var lockResult=screen.orientation.lock("landscape");
    if(lockResult&&lockResult.catch)lockResult.catch(function(){});
   }catch(_){}
  }
 }catch(error){
  try{console.warn("[JADWAL SHALAT] Fullscreen Display Mode tidak tersedia:",error);}catch(_){}
 }
}
function exitDisplayModeFullscreen(){
 try{if(document.fullscreenElement&&document.exitFullscreen)document.exitFullscreen();}catch(e){}
}
function openSettings(){
 slideshowSuppressed=true;
 hideSlideshowNow();
 enterDisplayModeFullscreen();
 try{history.pushState({settings:true},"",location.href.split("#")[0]+"#settings");}catch(e){}
 document.getElementById("sName").value=cfg.name;document.getElementById("sLocation").value=cfg.location;setLogoSource(brandingImage);document.getElementById("sAsr").value=cfg.asr;document.getElementById("sDhuha").value=cfg.dhuha;document.getElementById("sRunning").value=cfg.running;
 document.getElementById("sInfo").value=cfg.info||"";document.getElementById("sCash").value=cfg.cash||0;document.getElementById("sSpeed").value=cfg.runningSpeed==null?28:cfg.runningSpeed;document.getElementById("sSlideEnabled").value=String(cfg.slideEnabled===true||cfg.slideEnabled==="true");document.getElementById("sSlideAfter").value=cfg.slideAfter==null?15:cfg.slideAfter;document.getElementById("sSlideBefore").value=cfg.slideBefore==null?15:cfg.slideBefore;document.getElementById("sSlideDuration").value=cfg.slideDuration==null?15:cfg.slideDuration;renderSlideList();var h="",i,n;for(i=0;i<6;i++){n=["Subuh","Syuruq","Dzuhur","Ashar","Maghrib","Isya"][i];h+='<label>'+n+'<input id="a-'+n+'" type="number" value="'+(cfg.adjust[n]||0)+'"></label>'}document.getElementById("adjustGrid").innerHTML=h;var q="",qn=["Subuh","Dzuhur","Ashar","Maghrib","Isya"];for(i=0;i<qn.length;i++){n=qn[i];q+='<label>'+n+'<input id="q-'+n+'" type="number" min="0" max="120" value="'+(cfg.iqamah[n]||0)+'"></label>'}document.getElementById("iqamahGrid").innerHTML=q;setupLocations();document.getElementById("settings").className="settings"}
function closeSettings(){
 document.getElementById("settings").className="settings hidden";
 try{if(location.hash==="#settings")history.replaceState({__jadwalShalatBase:true},document.title,location.href.split("#")[0]);}catch(e){}
 slideshowSuppressed=false;
 var d=new Date(); updateSlideshow(d.getHours()*60+d.getMinutes()+d.getSeconds()/60);
}
function lockLandscape(){
 try{
  if(screen.orientation&&screen.orientation.lock){
   screen.orientation.lock("landscape").catch(function(){});
  }
 }catch(e){}
}
function bind(){var fsBtn=document.getElementById("enterFullscreenFromSettings");if(fsBtn)fsBtn.onclick=function(){enterDisplayModeFullscreen();};document.addEventListener("click",unlockAudio,{passive:true});document.addEventListener("touchstart",unlockAudio,{passive:true});document.addEventListener("pointerup",unlockAudio,{passive:true});document.addEventListener("keydown",unlockAudio,{passive:true});var outerSettingsButton=document.getElementById("outerSettingsButton")||document.getElementById("settingsButton");if(outerSettingsButton){
 var outerSettingsLastTap=0;
 var openOuterSettingsOnce=function(e){
  if(e){e.preventDefault();e.stopPropagation();}
  var now=Date.now();if(now-outerSettingsLastTap<700)return false;outerSettingsLastTap=now;
  try{openSettings();}catch(err){try{console.error("[JADWAL SHALAT] Gagal membuka pengaturan",err);}catch(_){}}
  return false;
 };
 outerSettingsButton.onclick=openOuterSettingsOnce;
 outerSettingsButton.ontouchend=openOuterSettingsOnce;
}var logoFile=document.getElementById("logoFile");if(logoFile)logoFile.onchange=function(){if(!logoFile.files||!logoFile.files[0])return;autoAdaptLogo(logoFile.files[0]).then(function(img){brandingImage=img;setLogoSource(img);return saveBranding(img)}).catch(function(){alert("Logo tidak dapat diproses. Silakan pilih gambar lain.")});};var resetLogoBtn=document.getElementById("resetLogo");if(resetLogoBtn)resetLogoBtn.onclick=resetLogo;var closeSettingsEl=document.getElementById("closeSettings");if(closeSettingsEl)closeSettingsEl.onclick=closeSettings;var saveSettingsEl=document.getElementById("saveSettings");if(saveSettingsEl)saveSettingsEl.onclick=function(){cfg.name=document.getElementById("sName").value||defaults.name;cfg.location=document.getElementById("sLocation").value;cfg.asr=document.getElementById("sAsr").value;cfg.dhuha=parseInt(document.getElementById("sDhuha").value,10)||15;cfg.running=document.getElementById("sRunning").value;
 cfg.info=document.getElementById("sInfo").value||"";cfg.cash=Math.max(0,parseInt(document.getElementById("sCash").value,10)||0);cfg.runningSpeed=Math.max(5,Math.min(120,parseInt(document.getElementById("sSpeed").value,10)||28));cfg.slideEnabled=document.getElementById("sSlideEnabled").value==="true";cfg.slideAfter=Math.max(0,parseInt(document.getElementById("sSlideAfter").value,10)||0);cfg.slideBefore=Math.max(0,parseInt(document.getElementById("sSlideBefore").value,10)||0);cfg.slideDuration=Math.max(3,parseInt(document.getElementById("sSlideDuration").value,10)||15);var i,n;for(i=0;i<6;i++){n=["Subuh","Syuruq","Dzuhur","Ashar","Maghrib","Isya"][i];cfg.adjust[n]=parseInt(document.getElementById("a-"+n).value,10)||0}var qn=["Subuh","Dzuhur","Ashar","Maghrib","Isya"];cfg.iqamah=cfg.iqamah||{};for(i=0;i<qn.length;i++){n=qn[i];cfg.iqamah[n]=Math.max(0,parseInt(document.getElementById("q-"+n).value,10)||0)}save();calculate(new Date());render();slideshowSuppressed=false;closeSettings();updateSlideshow(new Date().getHours()*60+new Date().getMinutes()+new Date().getSeconds()/60)};var resetSettingsEl=document.getElementById("resetSettings");if(resetSettingsEl)resetSettingsEl.onclick=function(){if(confirm("Reset semua pengaturan?")){cfg=cloneDefaults();save();openSettings()}};document.addEventListener("keydown",function(e){if(e.keyCode===27)closeSettings()})}
openBrandingDB().then(function(){return loadBranding()}).then(function(img){brandingImage=img||"";return loadLocalSlides();}).then(function(){
  /* Reload after cloud sync may have completed before the async app boot.
     This prevents the initial in-memory cfg from overwriting fresh cloud data. */
  cfg=load();
  normalizeIqamahConfig();
  bindLocalSlideControls();
  slides=normalizeSlideUrls(cfg.slideUrls||cfg.youtubeUrls||cfg.youtube||cfg.slides||cfg.slideUrlsText||[]).map(function(u,i){return {id:"remote-"+i,youtube:u,order:i+1,remote:true}});
  calculate(new Date());render();renderSlideList();bind();lockLandscape();update();appReady=true;syncOnline(new Date(),false);
});
/* JADWAL_SLIDESHOW_BACK_HANDLER */
ensureBackGuard();
function closeSlideshowFromBack(){
 var el=document.getElementById("slideshow");
 if(el && !el.classList.contains("hidden")){
  hideSlideshowNow();
  try{
   if(location.hash==="#slideshow")history.replaceState({__jadwalShalatBase:true},document.title,location.href.split("#")[0]);
  }catch(_){}
  return true;
 }
 return false;
}
window.addEventListener("popstate",function(){
 if(closeSlideshowFromBack()){
  slideshowSuppressed=true;
  try{history.replaceState({__jadwalShalatBase:true},document.title,location.href.split("#")[0]);}catch(_){ }
 }
 var settings=document.getElementById("settings");
 if(settings && location.hash!=="#settings")settings.className="settings hidden";
});
window.addEventListener("hashchange",function(){
 closeSlideshowFromBack();
});
document.addEventListener("keydown",function(e){
 if((e.key==="Escape"||e.key==="Backspace") && closeSlideshowFromBack()){
  e.preventDefault();
 }
});
document.addEventListener("fullscreenchange",function(){
 try{document.documentElement.classList.toggle("is-fullscreen",!!document.fullscreenElement);}catch(_){}
});
window.addEventListener("offline",function(){forceScheduleOnOffline();});
window.addEventListener("online",function(){
 setTimeout(function(){
  if(navigator.onLine!==false)probeInternetReachability();
 },350);
});
startNetworkProbe();
document.addEventListener("click",lockLandscape);setInterval(function(){update();var d=new Date();if(dateKey(d)!==lastDate){loadCachedOrCalculate(d);render();syncOnline(d,false)}},1000);
})();

// Android TV remote navigation + pairing panel
(function(){
  const pairing=document.getElementById('pairing');
  const openPairing=document.getElementById('openPairing');
  const closePairing=document.getElementById('closePairing');
  const openPairingFromSettings=document.getElementById('openPairingFromSettings');
  function showPairing(){ if(pairing) pairing.classList.remove('hidden'); }
  function hidePairing(){ if(pairing) pairing.classList.add('hidden'); }
  openPairing && openPairing.addEventListener('click',showPairing);
  openPairingFromSettings && openPairingFromSettings.addEventListener('click',showPairing);
  closePairing && closePairing.addEventListener('click',hidePairing);
  document.addEventListener('keydown',function(e){
    if(e.key==='Escape' || e.key==='Backspace'){
      if(pairing && !pairing.classList.contains('hidden')){ e.preventDefault(); hidePairing(); return; }
    }
    if((e.key==='Enter' || e.key===' ') && document.activeElement===openPairing){ e.preventDefault(); showPairing(); }
  });
})();

window.addEventListener("resize",scheduleInfoFit);window.addEventListener("orientationchange",()=>setTimeout(scheduleInfoFit,250));
