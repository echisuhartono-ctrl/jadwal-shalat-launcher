/* v0.4.37.32: scheduled Firestore sync; no continuous realtime listener to prevent screen flicker. */
(function(){
  'use strict';
  var firebaseConfig={apiKey:'AIzaSyAYEPKiLVsXFVJlHnPmtRu23vGywDlYsM4',authDomain:'tpa-digital-panggang.firebaseapp.com',projectId:'tpa-digital-panggang',storageBucket:'tpa-digital-panggang.firebasestorage.app',messagingSenderId:'744810848519',appId:'1:744810848519:web:3009dfff7ea6602938e5a2'};
  var ID_KEY='jadwalShalatMosqueId',SYNC_KEY='jadwalShalatSyncDoneId';
  var AUTO_SYNC_MINUTE=0; // Sinkron otomatis pada menit 00 setiap jam.
  var st=null,panel=null,idInput=null,msg=null;
  var db=null,ready=false,syncing=false,initStarted=false,scheduleTimer=null,lastRemoteSignature='';
  function refreshNodes(){st=document.getElementById('cloudSyncStatus');panel=document.getElementById('displayControl');idInput=document.getElementById('displayMosqueId');msg=document.getElementById('displayControlMsg');}
  function status(t){if(st){st.textContent=t;st.style.display='block';clearTimeout(status._t);status._t=setTimeout(function(){st.style.display='none'},3500)}if(msg)msg.textContent=t;}
  function getId(){try{return String(localStorage.getItem(ID_KEY)||'').trim()}catch(e){return ''}}
  function setId(v){try{localStorage.setItem(ID_KEY,v)}catch(e){}}
  function alreadySynced(id){try{return localStorage.getItem(SYNC_KEY)===id}catch(e){return false}}
  function markSynced(id){try{localStorage.setItem(SYNC_KEY,id)}catch(e){}}
  function openPanel(e){if(e){try{e.preventDefault();e.stopPropagation()}catch(x){}}if(panel)panel.classList.remove('hidden');if(idInput)idInput.value=getId();return false;}
  function closePanel(e){if(e){try{e.preventDefault();e.stopPropagation()}catch(x){}}if(panel)panel.classList.add('hidden');return false;}
  function bindControls(){
    var b=document.getElementById('displayControlButton'),c=document.getElementById('closeDisplayControl'),save=document.getElementById('saveDisplayMosqueId'),manual=document.getElementById('manualSyncButton');
    function once(el,key,fn){if(!el||el.getAttribute('data-bound-'+key)==='1')return;if(el.getAttribute('data-bound-'+key)==='1')return;el.setAttribute('data-bound-'+key,'1');el.addEventListener('click',fn,false);}
    once(b,'open',function(e){openPanel(e);});
    once(c,'close',function(e){closePanel(e);});
    once(save,'save',function(e){if(e){e.preventDefault();e.stopPropagation()}var id=String(idInput&&idInput.value||'').trim();if(!id){status('ID Masjid wajib diisi');return false}setId(id);try{localStorage.removeItem(SYNC_KEY)}catch(x){}status('ID Masjid disimpan. Mengambil konfigurasi terbaru...');sync(true).then(function(){scheduleNextSync()});return false;});
    once(manual,'sync',function(e){if(e){e.preventDefault();e.stopPropagation()}sync(true);return false;});
  }
  function waitForFirebase(){return new Promise(function(resolve,reject){var n=0;(function tick(){if(window.firebase&&typeof firebase.initializeApp==='function'&&typeof firebase.firestore==='function')return resolve(firebase);if(++n>120)return reject(new Error('Firebase SDK tidak tersedia setelah menunggu'));setTimeout(tick,100)})();});}
  function mergeAndApply(d,notify){
    /* v0.4.37.32: apply cloud config to the live app immediately.
       Do not rely on browser reload/back navigation to reveal the new schedule. */
    var old={};try{old=JSON.parse(localStorage.getItem('jadwalShalatConfig')||'{}')}catch(e){}
    var next={};Object.keys(old).forEach(function(k){next[k]=old[k]});
    Object.keys(d||{}).forEach(function(k){if(d[k]!==undefined)next[k]=d[k]});
    var sig='';try{sig=JSON.stringify(next)}catch(e){sig=String(Date.now())}
    var changed=false;try{changed=sig!==JSON.stringify(old)}catch(e){changed=true}
    lastRemoteSignature=sig;
    try{localStorage.setItem('jadwalShalatConfig',sig)}catch(e){}
    try{
      if(typeof window.applyJadwalCloudConfig==='function'){
        window.applyJadwalCloudConfig(d||{});
      }
    }catch(e){try{console.warn('[JADWAL SHALAT] live cloud apply failed',e);}catch(_) {}}
    return changed;
  }
  function sync(force){
    var id=getId();
    if(!id){status('ID Masjid belum diatur');openPanel();return Promise.resolve(false)}
    if(!ready||!db){status('Firebase belum siap, coba lagi sebentar...');initFirebase();return Promise.resolve(false)}
    if(syncing)return Promise.resolve(false);
    if(!force&&alreadySynced(id))return Promise.resolve(true);
    syncing=true;
    status('Sinkronisasi terjadwal: mengambil konfigurasi...');
    return db.collection('jadwalShalat').doc(id).get().then(function(s){
      if(!s.exists)throw new Error('Konfigurasi ID masjid belum ada');
      mergeAndApply(s.data()||{},true);
      markSynced(id);
      closePanel();
      try{
        var display=document.getElementById('display');
        if(display){display.classList.remove('hidden');display.style.visibility='visible';display.style.opacity='1';display.style.pointerEvents='auto';}
        var stage=document.getElementById('tvStage');
        if(stage)stage.classList.remove('slideshow-mode');
      }catch(e){}
      status('Sinkronisasi selesai — jadwal diterapkan');
      return true;
    }).catch(function(e){
      status('Cloud gagal: '+(e&&e.message||'periksa koneksi'));
      return false;
    }).then(function(v){syncing=false;return v},function(){syncing=false;return false});
  }
  function scheduleNextSync(){
    if(scheduleTimer)clearTimeout(scheduleTimer);
    var now=new Date(),next=new Date(now.getTime());
    next.setSeconds(0,0);
    next.setMinutes(AUTO_SYNC_MINUTE);
    if(next.getTime()<=now.getTime())next.setHours(next.getHours()+1);
    var delay=Math.max(1000,next.getTime()-now.getTime());
    scheduleTimer=setTimeout(function(){
      sync(true).then(function(){scheduleNextSync()});
    },delay);
    status('Sinkron otomatis dijadwalkan pada menit 00 setiap jam');
  }
  function initFirebase(){
    if(initStarted)return;
    initStarted=true;
    waitForFirebase().then(function(fb){
      try{if(!fb.apps.length)fb.initializeApp(firebaseConfig)}catch(e){}
      try{
        db=fb.firestore();ready=true;status('Cloud siap');
        var id=getId();
        if(id)sync(false);
        scheduleNextSync();
      }catch(e){status('Firestore tidak tersedia')}
    }).catch(function(){
      ready=false;
      status('Firebase belum siap — tombol manual tetap tersedia');
      setTimeout(function(){initStarted=false;initFirebase()},4000);
    });
  }
  window.jadwalShalatCloudSync={sync:sync,open:openPanel,ready:function(){return ready},scheduleNextSync:scheduleNextSync};
  function boot(){refreshNodes();bindControls();initFirebase()}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
})();
